<?php namespace App\Controllers;

use CodeIgniter\Controller;

class Pages extends BaseController
{
	public $form_validation;
	protected $PendaftaranModel;
	protected $ContacModel;	
	public function __construct()
    {
        helper(['form','html']);
    }

	public function index()
	{
		$data = [
			'title' => 'WEB3 - Pertemuan 3',
			'request' => $this->request->uri->getSegment(1)
		];
		echo view('pages/home', $data);	
	}

	public function about()
	{
		// $request = \Config\Services::request();
		$data = [
			'title' => 'About Me',
			'tentang' => 'Our Team',
			'request' => $this->request->uri->getSegment(2)
		];
		echo view('pages/about', $data);		
	}

	public function contact()
	{
		$data = [
			'title' => 'Contact Us',
			'request' => $this->request->uri->getSegment(2)
		
		];
		echo view('pages/contact', $data);		
	}

	public function kirim_pesan()
	{
		$nama		= $this->request->getVar('nama');
		$email		= $this->request->getVar('email');
		$pesan 		= $this->request->getVar('pesan');
		$data = [
			'nama'			=>	$nama,
			'email' 		=>	$email,
			'pesan'			=>	$pesan
		];
		if($this->form_validation->run($data, 'validatePesan') == FALSE){
			session()->setFlashData('inputs', $this->request->getVar());
			session()->setFlashData('errors', $this->form_validation->getErrors());
			return redirect()->to(base_url('pages/contact'));
		}else{
			$this->ContacModel->insert([
				'nama'			=>	$nama,
				'email'			=>	$email,
				'pesan'			=>	$pesan
			]);
			
			session()->setFlashData('success','Pesan Berhasil dikirim');
			return redirect()->to(base_url('pages/contact'));
		}
	}

	public function daftar(){
		
		$data = [
			'title' => 'form pendaftaran',
			'request' => $this->request->uri->getSegment(2)
		];
		echo view('pages/daftar', $data);
		
	}

	public function daftar_akun(){
		$nama		= $this->request->getPost('nama');
		$email		= $this->request->getPost('email');
		$telpon		= $this->request->getPost('telpon');
		$file 		= $this->request->getPost('file_upload');
		$username 	= $this->request->getPost('username');
		$password	= $this->request->getPost('password');
		$data = [
			'nama'			=>	$nama,
			'email' 		=>	$email,
			'telpon'		=>	(int)$telpon,
			'file_upload'	=>	$file,
			'username' 		=> $username,
			'password'		=> $password
		];
		if($this->form_validation->run($data, 'validate') == FALSE){
			session()->setFlashData('inputs', $this->request->getVar());
			session()->setFlashData('errors', $this->form_validation->getErrors());
			return redirect()->to(base_url('pages/daftar'));
		}else{
			$avatar = $this->request->getFile('file_upload');
			// generate nama avatar
			$namaAvatarBaru = $avatar->getRandomName();
			// memindahkan file
			$avatar->move('uploads', $namaAvatarBaru);	
			// dd($this->request->getVar());
			// if($avatar->isValid()){
			// 	$avatar->move(ROOTPATH . 'public/uploads');
			// }
			// session()->setFlashData('success','pendaftaran berhasil');
			// return redirect()->to(base_url('pages/daftar'));
			$this->PendaftaranModel->save([
				'nama'			=>	$nama,
				'email'			=>	$email,
				'telpon'		=>	$telpon,
				'avatar'		=>	$namaAvatarBaru,
				'username'		=>	$username,
				'password'		=>	$password
			]);
			session()->setFlashData('success','pendaftaran berhasil data tersimpan di database');
			return redirect()->to(base_url('pages/daftar'));
		}
	}
	


}
