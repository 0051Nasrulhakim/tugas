<?= $this->extend('/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-lg-4 container-fluid">
			<h4 class="card-title mt-3 text-center">Daftar Akun Baru</h4>
			<p class="text-center">Klik daftar untuk membuat akun</p>
			<?php 
			echo form_open_multipart('pages/daftar_akun');

			$inputs 	= session()->getFlashdata('inputs');
			$errors 	= session()->getFlashdata('errors');
			$success 	= session()->getFlashdata('success');
			if(!empty($errors)){?>
			<div class="alert alert-danger" role="alert">
				ada kesalahan saat input data yaitu :
				<ul>
					<?php foreach($errors as $error):?>
						<li><?= $error?></li>
					<?php endforeach;?>
				</ul>
			</div>
			<?php }
			
			if(!empty($success)){ ?>
				<div class="alert alert-success" role="alert">
					<?= $success?>
				</div>
			<?php }
			?>

			<div class="form-group input-group">
				<div class="input-group-prepend">
					<span class="input-group-text"> <i class="fa fa-user"></i> </span>
				</div>
				<?php 
				$data = [
					'name'      	=> 'nama',
					'id'        	=> 'nama',
					'placeholder'	=> 'Nama lengkap',
					'class'			=> 'form-control'
				];
				$values = ($inputs == null ? '': $inputs['nama']);
				echo form_input($data);
				?>
			</div> 
			<div class="form-group input-group">
				<div class="input-group-prepend">
					<span class="input-group-text"> <i class="fa fa-envelope"></i> </span>
				</div>
				<?php 
				$data = [
					'name'      	=> 'email',
					'id'        	=> 'email',
					'placeholder'	=> 'Alamat email',
					'class'			=> 'form-control',
					'type'			=> 'email'
				];
				$values = ($inputs == null ? '': $inputs['email']);
				echo form_input($data);
				?>
			</div> 
			<div class="form-group input-group">
				<div class="input-group-prepend">
					<span class="input-group-text"> <i class="fa fa-phone"></i> </span>
				</div>
				<?php 
				$data = [
					'name'      	=> 'telpon',
					'id'        	=> 'telpon',
					'placeholder'	=> 'Nomor telepon',
					'class'			=> 'form-control',
					'type'			=> 'number',
				];
				
				echo form_input($data);
				?>
			</div> 

			<div class="form-group input-group mb-3">
				<div class="input-group-prepend">
					<span class="input-group-text"><i class="fa fa-cloud-upload" aria-hidden=true></i></span>
				</div>
				<div class="custom-file">
					<input type="file" class="custom-file-input" id="inputGroupFile01">
					<?php 
					$data = [
						'name'      	=> 'file_upload',
						'id'        	=> 'inputGroupFile01',
						'class'			=> 'custom-file-input'
					];
					echo form_upload($data);
					?>
					<label class="custom-file-label" for="inputGroupFile01">Pilih file</label>
				</div>
			</div>
			<div class="form-group input-group">
				<div class="input-group-prepend">
					<span class="input-group-text"> <i class="fa fa-user"></i> </span>
				</div>
				<?php 
				$data = [
					'name'      	=> 'username',
					'id'        	=> 'username',
					'placeholder'	=> 'Masukkan username',
					'class'			=> 'form-control'
				];
				$values = ($inputs == null ? '': $inputs['username']);
				echo form_input($data);
				?>
			</div>
			<div class="form-group input-group">
				<div class="input-group-prepend">
					<span class="input-group-text"> <i class="fa fa-lock"></i> </span>
				</div>
				<?php 
				$data = [
					'name'      	=> 'password',
					'id'        	=> 'password',
					'placeholder'	=> 'Masukkan password',
					'class'			=> 'form-control'
				];
				$values = ($inputs == null ? '': $inputs['password']);
				echo form_password($data);
				?>
			</div> 

			<div class="form-group">
				<button type="submit" class="btn btn-primary btn-block"> Daftar Akun  </button>
			</div> 
			<p class="text-center">Sudah punya akun? <a href="">Masuk sekarang</a> </p>                                                                 
			<?php echo form_close(); ?>
		</div>
	</div>
</div>
<?= $this->endSection(); ?>