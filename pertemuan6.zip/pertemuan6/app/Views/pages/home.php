<?= $this->extend('/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
	<div class="row">
		<div class="col">
			<h1>HELLO MY NAME IS NASRUL !</h1>
			<H2>NIM 19.240.0051</H2>
			<h2>THIS is formatif exam web programing 3 - chapter 5-6</h2>
		</div>
	</div>
</div>
<?= $this->endSection(); ?>
