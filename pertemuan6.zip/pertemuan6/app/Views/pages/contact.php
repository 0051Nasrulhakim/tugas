<?= $this->extend('/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
	<div class="row">
		<div class="col">
            <div class="card">
                <div class="card-header bg-primary text-white"><i class="fa fa-envelope"></i> Contact us.
                </div>
                <div class="card-body">
                    <?php echo form_open('pages/kirim_pesan'); 
                        $inputs 	= session()->getFlashdata('inputs');
                        $errors 	= session()->getFlashdata('errors');
                        $success 	= session()->getFlashdata('success');
                        if(!empty($errors)){?>
                            <div class="alert alert-danger" role="alert">
                                ada kesalahan saat input data yaitu :
                                <ul>
                                    <?php foreach($errors as $error):?>
                                        <li><?= $error?></li>
                                    <?php endforeach;?>
                                </ul>
                            </div>
                            <?php }
                            
                            if(!empty($success)){ ?>
                                <div class="alert alert-success" role="alert">
                                    <?= $success?>
                                </div>
                            <?php }
                            ?>
                
                    
                        <div class="form-group">
                            <?php 
                                echo form_label('Nama', 'nama');
                            	$data = [
                            	        'name'      	=> 'nama',
								        'id'        	=> 'nama',
								        'placeholder'	=> 'Masukkan nama',
								        'class'			=> 'form-control'
								];
                                $values = ($inputs == null ? '': $inputs['nama']);
								echo form_input($data);

                             ?>
                        </div>
                        <div class="form-group">
                            <?php 
                                echo form_label('Email', 'email');
                                $data = [
                                        'name'          => 'email',
                                        'id'            => 'email',
                                        'placeholder'   => 'Masukkan email',
                                        'class'         => 'form-control',
                                        'type'          => 'email'
                                ];
                                $values = ($inputs == null ? '': $inputs['email']);
                                echo form_input($data);
                             ?>

                            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                        </div>
                        <div class="form-group">
                            
                            <?php 
                                echo form_label('Pesan', 'pesan');
                                $data = [
                                        'name'          => 'pesan',
                                        'id'            => 'pesan',
                                        'placeholder'   => 'Masukkan pesan',
                                        'class'         => 'form-control',
                                        'rows'          => '6'
                                ];
                                $values = ($inputs == null ? '': $inputs['pesan']);
                                echo form_textarea($data);

                             ?>
                        </div>
                        <div class="mx-auto">
                        <!-- <button type="submit" class="btn btn-primary text-right">Submit</button> -->
                        <?php 
                            $data = [
                                    'name'          => 'kirim',
                                    'value'         => 'Kirim Pesan',
                                    'class'         => 'btn btn-primary text-right'
                            ];
                            echo form_submit($data);
                         ?>
                        </div>
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
	</div>
</div>
<?= $this->endSection(); ?>
