<?= $this->extend('/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
	<div class="row">
		<div class="col">
			<h1><?= $tentang;?></h1>
			
			 <div class="row text-center">
			 	<!-- Team item-->
			 	<div class="col-xl-6 col-sm-6 mb-5">
			 		<div class="bg-white rounded shadow-sm py-5 px-4">
			 			<?php echo img('assets/img/woman.png', false, ['class' => 'img-fluid rounded-circle mb-3 img-thumbnail shadow-sm', 'width' => '100']); ?>
			 			<h5 class="mb-0">Manuella Nevoresky</h5><span class="small text-uppercase text-muted">CEO - Founder</span>
			 			<ul class="social mb-0 list-inline mt-3">
			 				<li class="list-inline-item"><a href="#" class="social-link"><i class="fa fa-facebook-f"></i></a></li>
			 				<li class="list-inline-item"><a href="#" class="social-link"><i class="fa fa-twitter"></i></a></li>
			 				<li class="list-inline-item"><a href="#" class="social-link"><i class="fa fa-instagram"></i></a></li>
			 				<li class="list-inline-item"><a href="#" class="social-link"><i class="fa fa-linkedin"></i></a></li>
			 			</ul>
			 		</div>
			 	</div>
			 	<!-- End-->
			 	<!-- Team item-->
			 	<div class="col-xl-6 col-sm-6 mb-5">
			 		<div class="bg-white rounded shadow-sm py-5 px-4">
			 			<?php echo img('assets/img/man.png', false, ['class' => 'img-fluid rounded-circle mb-3 img-thumbnail shadow-sm', 'width' => '100']); ?>
			 			<h5 class="mb-0">Samuel Hardy</h5><span class="small text-uppercase text-muted">CEO - Founder</span>
			 			<ul class="social mb-0 list-inline mt-3">
			 				<li class="list-inline-item"><a href="#" class="social-link"><i class="fa fa-facebook-f"></i></a></li>
			 				<li class="list-inline-item"><a href="#" class="social-link"><i class="fa fa-twitter"></i></a></li>
			 				<li class="list-inline-item"><a href="#" class="social-link"><i class="fa fa-instagram"></i></a></li>
			 				<li class="list-inline-item"><a href="#" class="social-link"><i class="fa fa-linkedin"></i></a></li>
			 			</ul>
			 		</div>
			 	</div>
			 	<!-- End-->
			 </div>




		</div>
	</div>
</div>
<?= $this->endSection(); ?>
