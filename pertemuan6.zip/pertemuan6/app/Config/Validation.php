<?php

namespace Config;

use CodeIgniter\Validation\CreditCardRules;
use CodeIgniter\Validation\FileRules;
use CodeIgniter\Validation\FormatRules;
use CodeIgniter\Validation\Rules;

class Validation
{
    //--------------------------------------------------------------------
    // Setup
    //--------------------------------------------------------------------

    /**
     * Stores the classes that contain the
     * rules that are available.
     *
     * @var string[]
     */
    public $ruleSets = [
        Rules::class,
        FormatRules::class,
        FileRules::class,
        CreditCardRules::class,
    ];

    /**
     * Specifies the views that are used to display the
     * errors.
     *
     * @var array<string, string>
     */
    public $templates = [
        'list'   => 'CodeIgniter\Validation\Views\list',
        'single' => 'CodeIgniter\Validation\Views\single',
    ];

    

    //--------------------------------------------------------------------
    // Rules
    //--------------------------------------------------------------------
    public $validate = [
        'nama'  =>[
            'rules'     => 'required|alpha_space',
            'errors'    =>  [
                'required'      => 'nama harus diisi',
                'alpha_space'   =>  'nama tidak boleh mengandung selain huruf dan spasi'
            ]
        ],
        'email' => [
            'rules'     => 'required|valid_emails',
            'errors'    =>  [
                'required'      => 'email harus diisi',
                'valid_emails'   =>'email anda tidak valid'
            ]
        ],
        'username'  => [
            'rules'     => 'required|alpha_numeric|min_length[5]|max_length[20]',
            'errors'    => [
                'required'       => '{field} wajib di isi',
                'alpha_numeric'  => '{field} hanya boleh diisi huruf dan angka',
                'min_length'     => '{field} minimal terdiri dari 5 huruf',
                'max_length'     => '{field} maximal terdiri dari 20 huruf'
            ]
        ], 
        'file_upload'=> [
            'rules'     => 'uploaded[file_upload]|is_image[file_upload]|max_size[file_upload,2025]',
            'errors'    => [
                'uploaded'      =>  'masukkan gambar terlebih dahulu',
                'max_size'      =>  'ukuran gambar terlalu besar',
                'is_image'      =>  'yang anda pilih bukan gambar',
            ]
        ],
        'telpon'   => [
            'rules'    => 'numeric',
            'errors'   => [
                'numeric' => 'nomor hanya boleh di isi angka'
            ]
        ],
        'password'  => [
            'rules' => 'min_length[8]|max_length[20]',
            'errors'=>  [
                'min_length' => 'password minimal 8 karakter',
                'max_length' => 'password maximal 20 karakter'
            ]
        ],
        
    ];

    public $validatePesan = [
        'pesan'     =>[
            'rules' => 'max_length[900]',
            'errors'=>  'pesan terlalu panjang'
        ],
        'nama'  =>[
            'rules'     => 'required|alpha_space',
            'errors'    =>  [
                'required'      => 'nama harus diisi',
                'alpha_space'   =>  'nama tidak boleh mengandung selain huruf dan spasi'
            ]
        ],
        'email' => [
            'rules'     => 'required|valid_emails',
            'errors'    =>  [
                'required'      => 'email harus diisi',
                'valid_emails'   =>'email anda tidak valid'
            ]
        ]
    ];
}
